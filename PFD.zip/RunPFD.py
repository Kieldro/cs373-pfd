import sys

from PFD import *

run(sys.stdin, sys.stdout)
