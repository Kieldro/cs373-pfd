Course Name: CS373
Unique: 91055

First Name: Ian
Last Name: Buitrago
EID: ib
E-mail: kieldro@gmail.com
Estimated number of hours: 12
Actual    number of hours: 10

Partner First Name: Fayz
Partner Last Name: Rahman
Partner EID: fnr75
Partner E-mail: fayz.rahman@utexas.edu
Partner Estimated number of hours: 10
Partner Actual number of hours: 10

Turnin CS Username: keo
GitHub ID: Kieldro
GitHub Repository Name: cs373-pfd

Comments:
* hashbang in script?
* modify loop inside loop?

TODO:

----------------
Pair Programming
----------------

I attest to that fact that, of the time spent working on this project,
at least seventy-five (75) percent was spent working with the person
listed above in pair programming.

---------------
Code of Conduct
---------------

I attest that I have written every line of code that I have submitted
and I take full responsibility for the origin of all the code submitted.
In particular, if any of the code was originally written in a previous
semester or another course I will so acknowledge via e-mail to the
grader.
